# Proyecto Tricorder ESP32-S3 en Español

Este proyecto utiliza un ESP32-S3, una pantalla TFT 1.8" (driver ST7735S), cinco botones y un altavoz para mostrar animaciones GIF y reproducir sonidos almacenados en la memoria flash (SPIFFS).

## Funcionamiento

- **Botón 1 (GPIO12):** Reproduce la animación y sonido 1 del grupo activo.
- **Botón 2 (GPIO13):** Reproduce la animación y sonido 2 del grupo activo.
- **Botón 3 (GPIO14):** Reproduce la animación y sonido 3 del grupo activo.
- **Botón 4 (GPIO16):** Cambia entre el grupo 1 y el grupo 2.
- **Botón 5 (GPIO17):** Reproduce la animación y sonido de alarma (siempre el mismo).

## Estructura de Carpetas

```
tricorder_esp32s3/
├── tricorder_esp32s3.ino
├── README.md
├── data/
│   ├── group1_1.gif
│   ├── group1_1.wav
│   ├── group1_2.gif
│   ├── group1_2.wav
│   ├── group1_3.gif
│   ├── group1_3.wav
│   ├── group2_1.gif
│   ├── group2_1.wav
│   ├── group2_2.gif
│   ├── group2_2.wav
│   ├── group2_3.gif
│   ├── group2_3.wav
│   ├── alarm.gif
│   └── alarm.wav
```

## Conexiones

### Pantalla TFT ST7735S

| ESP32-S3 GPIO | Pantalla TFT | Función          |
|---------------|--------------|------------------|
| 3V3           | VCC          | Alimentación     |
| GND           | GND          | Tierra           |
| 18            | SCL/SCK      | SPI Clock        |
| 23            | SDA/MOSI     | SPI Data         |
| 5             | DC/A0        | Data/Command     |
| 4             | RST          | Reset            |
| 15            | CS           | Chip Select      |

### Botones

- Un pin a GND
- El otro pin a GPIO: 12, 13, 14, 16, 17 según la función

### Altavoz

Conecta un pequeño altavoz a la salida I2S del ESP32 (ver pines en el código o documentación de tu placa).

## Librerías necesarias

- **TFT_eSPI**
- **AnimatedGIF**
- **ESP32-audioI2S**

Instala todas desde el Gestor de Bibliotecas de Arduino.

## Configuración TFT_eSPI (User_Setup.h)

Ejemplo:
```cpp
#define ST7735_DRIVER
#define TFT_WIDTH  128
#define TFT_HEIGHT 160
#define TFT_MOSI 23
#define TFT_SCLK 18
#define TFT_CS   15
#define TFT_DC   5
#define TFT_RST  4
#define LOAD_GLCD
#define LOAD_FONT2
#define LOAD_FONT4
#define LOAD_GFXFF
#define SPI_FREQUENCY  27000000
```

## Cargar archivos al SPIFFS

1. Pon los archivos `.gif` y `.wav` en la carpeta `data/`.
2. Usa la herramienta **ESP32 Sketch Data Upload** del menú "Tools" en Arduino IDE para subirlos a la memoria.
3. Los nombres deben coincidir con los del código.

## Formatos recomendados

- GIF: Animados, máximo 128x160 píxeles, color indexado.
- WAV: PCM 8/16 bits, mono, entre 8kHz y 44kHz.

## Diagrama de conexión (Fritzing)

### Texto

```
[ESP32-S3]                [TFT ST7735S]
3V3  --------------------> VCC
GND  --------------------> GND
GPIO18 ------------------> SCL/SCK
GPIO23 ------------------> SDA/MOSI
GPIO5  ------------------> DC/A0
GPIO4  ------------------> RST
GPIO15 ------------------> CS

[Botones] 
Un pin a GND, el otro a GPIO12, GPIO13, GPIO14, GPIO16, GPIO17

[Altavoz]
Salida I2S (por defecto GPIO25, 26, 22)
```

### Imagen

![Diagrama de conexiones ESP32-S3 Tricorder](https://i.imgur.com/WZ7zF2l.png)

---

¿Dudas? ¿Quieres agregar más grupos, efectos, o ayuda con los GIF/WAV? ¡Solo pregunta!